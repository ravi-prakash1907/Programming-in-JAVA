/**
 * Auto Generated Java Class.
 */
import Practical17package.*;
public class Practical17 {
  
 public static void main(String args[])
 {
   
  Practical17package p1= new Practical17package();
  p1.readString();
  System.out.println(p1.str1);
  //System.out.println(p1.str2);
  //System.out.println(p1.str3);
  
  Practical17packageextends p2= new Practical17packageextends();
  p2.readStringextends();
  System.out.println(p2.str1);
  //System.out.println(p2.str2);
  //System.out.println(p2.str2);
   
   
   
 }
  
}
