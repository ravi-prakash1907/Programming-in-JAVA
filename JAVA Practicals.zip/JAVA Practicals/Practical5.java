/**
 * Auto Generated Java Class.
 */
import java.util.Scanner;
public class Practical5 {
  
  
  public static void main(String[] args) { 
    
      int n;
      String str1;
      Scanner s= new Scanner(System.in);
     System.out.println("input no");
     n=s.nextInt();
     str1=Integer.toBinaryString(n);
     System.out.println("binary=   "+str1);
      
      
     
  }
}