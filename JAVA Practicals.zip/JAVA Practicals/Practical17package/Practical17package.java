/**
 * Auto Generated Java Class.
 */
package Practical17package;
import java.util.Scanner;


public class Practical17package {
  public String str1;
  private String str2;
  protected String str3;
  public void readString()
  {
    Scanner s= new Scanner(System.in);
    System.out.println("enter string");
    str1=s.nextLine();
     System.out.println("enter string");
    str2=s.nextLine();
     System.out.println("enter string");
    str3=s.nextLine();
    
  }
  
  
}
