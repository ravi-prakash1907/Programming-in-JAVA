/**
 * Auto Generated Java Class.
 */
import java.lang.*;
public class Practical14 {
  
  public static void main(String args[]){
  
   Integer i1,i2;
   int ii1,ii2;
   i1=100;i2=200;
   ii1=i1;
   ii2=i2;
   System.out.println(i1);
   System.out.println(i2);
   System.out.println(ii1);
   System.out.println(ii2);
   
   
   i1=i1+i2;
   
   System.out.println(i1);
   System.out.println(i2);
   
   i1=i1/2;
   System.out.println(i1);
   System.out.println(i2);
  }
}
