/**
 * Auto Generated Java Class.
 */
package Practical15package;
import java.util.Scanner;


public class Practical15package {
  public String str1;
  public void readString()
  {
    Scanner s= new Scanner(System.in);
    System.out.println("enter string");
    str1=s.nextLine();
    
    
    
  }
  
  
}
