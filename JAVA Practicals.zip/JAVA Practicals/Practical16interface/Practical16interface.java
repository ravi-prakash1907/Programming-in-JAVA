/**
 * Auto Generated Java Class.
 */
package Practical16interface;

public interface Practical16interface
{
  
 public int fibo(int n); 
  
  
  
}
