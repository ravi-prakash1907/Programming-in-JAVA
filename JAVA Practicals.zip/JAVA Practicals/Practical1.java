/**
 * Auto Generated Java Class.
 */
public class Practical1 {
  
  
  public static void main(String args[]) { 
    int len;
  int sum;
    len=args.length;
    System.out.println("len=   "+len);
    sum=0;
    for(int i=0;i<=len-1;++i)
    {
      sum=sum+Integer.parseInt(args[i]);
    
  }
  System.out.println("Sum=   "+sum);
  /* ADD YOUR CODE HERE */
  
}
}
