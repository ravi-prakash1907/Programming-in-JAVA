/**
 * Auto Generated Java Class.
 */
package Practical17package;
import java.util.Scanner;



public class Practical17packageextends extends Practical17package
{
   public void readStringextends()
  {
    Scanner s= new Scanner(System.in);
    System.out.println("enter string");
    str1=s.nextLine();
     System.out.println("enter string");
    //str2=s.nextLine();
     System.out.println("enter string");
    str3=s.nextLine();
    
  } 
  
  
}