/**
 * Auto Generated Java Class.
 */
import Practical15package.*;
public class Practical15 {
  
 public static void main(String args[])
 {
   
  Practical15package p1= new Practical15package();
  p1.readString();
  System.out.println(p1.str1);
   
   
   
 }
  
}
